from setuptools import setup

setup(
    name="Byond_API",
    version='0.1.0',
    url="https://github.com/HaCsO/Byond-API",
    description="Simple way to take data from BYOND",
    packages=['Byond_API'],
    author_email="hacso@mail.ru",
    zip_file=False,
)